/**
 * Created by jekibalamhaque on 04/07/16.
 */
var mainApp = angular.module('mainApp', ['ngRoute']);

// configure our routes
mainApp.config(function($routeProvider) {
    $routeProvider

    // route for the home page
    //     .when('/', {
    //         templateUrl : 'index.html',
    //         controller  : 'mainController'
    //     })
        .when('/add', {
            templateUrl : 'addFilm.html',
            controller  : 'mainController'
        })

        // route for the about page
        .when('/modify', {
            templateUrl : 'modifyFilm.html',
            controller  : 'aboutController'
        })
        .when('/delete', {
            templateUrl : 'deleteFilm.html',
            controller  : 'aboutController'
        })

        // route for the contact page
        .when('/search', {
            templateUrl : 'searchFilm.html',
            controller  : 'contactController'
        });
});

// create the controller and inject Angular's $scope
mainApp.controller('mainController', function($scope) {
    // create a message to display in our view
    $scope.message = 'Everyone come and see how good I look!';
});

mainApp.controller('aboutController', function($scope) {
    $scope.message = 'Look! I am an about page.';
});

mainApp.controller('contactController', function($scope) {
    $scope.message = 'Contact us! JK. This is just a demo.';
});